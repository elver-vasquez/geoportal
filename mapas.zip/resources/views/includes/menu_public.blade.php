<ul id="dropmenu" class="menu">
    <!--CURRENT MENU ITEM (class name = current-menu-item)-->
    <li class="current-menu-item"><a href="index.html">INICIO</a>
        <ul class="sub-menu">
            <li><a href="#">Africa</a></li>
            <li><a href="#">Asia</a></li>
            <li><a href="#">Australia</a></li>
            <li><a href="#">Europe</a></li>
            <li><a href="#">North America</a></li>
            <li><a href="#">South America</a></li>
            <li><a href="#">View All</a></li>
        </ul>
    </li>
    <li><a href="about.html">MENU1</a></li>
    <li><a href="blog.html">MENU2</a></li>
    <li><a href="contact.html">MENU3</a></li>
    <li><a target="_blank" href="{{url('/home')}}">Ingresa &rarr;</a></li>
</ul>