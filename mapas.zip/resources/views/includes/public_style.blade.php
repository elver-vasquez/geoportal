<!--GOOGLE CUSTOM FONT LINK-->

{{--<link href='http://fonts.googleapis.com/css?family=Gruppo' rel='stylesheet' type='text/css' />--}}

{{--<link rel="stylesheet" href="{{asset('assets/style.css')}}" type="text/css" media="screen" />--}}
{{--<link rel="stylesheet" href="{{asset('assets/vendor/bootstrap/css/bootstrap.css')}}" />--}}
{{--<link rel="stylesheet" href="{{asset('assets/vendor/menu-horizontal/menu.css')}}" />--}}


{{--<link rel="stylesheet" href="{{asset('assets/scripts/prettyPhoto.css')}}" type="text/css" media="screen" />--}}
{{--<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/pure-min.css">--}}
<!-- Specific Page Vendor CSS -->
{{--<link rel="stylesheet" href="{{asset('assets/vendor/jstree/themes/default/style.css')}}" />--}}

<!-- Theme CSS -->
{{--<link rel="stylesheet" href="{{asset('assets/stylesheets/theme.css')}}" />--}}

<!-- Skin CSS -->
{{--<link rel="stylesheet" href="{{asset('assets/stylesheets/skins/default.css')}}" />--}}

<!-- Theme Custom CSS -->
{{--<link rel="stylesheet" href="{{asset('assets/stylesheets/theme-custom.css')}}">--}}

<!-- Head Libs -->
