<!--SCRIPTS-->
<script src="{{asset('assets/vendor/jquery/jquery.js')}}"></script>
<script src="{{asset('assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js')}}"></script>
<script src="{{asset('assets/vendor/bootstrap/js/bootstrap.js')}}"></script>

<script type="text/javascript" src="{{asset('assets/scripts/jquery-ui-1.8.13.custom.min.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/scripts/prettyphoto.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/scripts/activity.js')}}"></script>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?v=3.13&sensor=false"></script>
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>
<script type="text/javascript" src="{{asset('assets/scripts/gmap3.min.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/scripts/jquery.backstretch.min.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/scripts/jquery.animate-colors-min.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/scripts/custom.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/vendor/menu-horizontal/menu.js')}}"></script>


<!-- Specific Page Vendor -->
<script src="{{asset('assets/vendor/jstree/jstree.js')}}"></script>

<!-- Theme Base, Components and Settings -->
<script src="{{asset('assets/javascripts/theme.js')}}"></script>

<!-- Theme Custom -->
<script src="{{asset('assets/javascripts/theme.custom.js')}}"></script>

<!-- Theme Initialization Files -->
<script src="{{asset('assets/javascripts/theme.init.js')}}"></script>


<!-- Examples -->
<script src="{{asset('assets/javascripts/ui-elements/examples.treeview.js')}}"></script>

@yield('myscripts')


