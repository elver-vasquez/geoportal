@extends('layouts.main')

@section('head')
    @stop

@section('title')
    Sistema  Cuencas
    @stop
@section('styles')

    @stop

@section('body')
    @yield('content')

@stop