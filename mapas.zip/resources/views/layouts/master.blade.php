<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    @yield('head')

</head>
<body>
@yield('body')
@yield('scripts')

</body>
</html>