<!-- Vendor -->
<script src="<?php echo e(asset('assets/vendor/jquery/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/nanoscroller/nanoscroller.js')); ?>"></script>

<script src="<?php echo e(asset('assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/magnific-popup/magnific-popup.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-placeholder/jquery.placeholder.js')); ?>"></script>

<!-- Theme Base, Components and Settings -->
<script src="<?php echo e(asset('assets/javascripts/theme.js')); ?>"></script>

<!-- Theme Custom -->



<?php echo $__env->yieldContent('myscripts'); ?>