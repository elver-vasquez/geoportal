<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <?php echo $__env->yieldContent('head'); ?>

</head>
<body>
<?php echo $__env->yieldContent('body'); ?>
<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>